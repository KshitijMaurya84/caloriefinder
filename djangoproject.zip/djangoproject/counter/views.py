
import imp
from wsgiref import headers
from django.shortcuts import render

# DCVMdrMM9Gaj2KEJUAF7ig==iuHAfu3JeQjphdAc
# Create your views here.
def home(request):
    import json
    import requests
    if request.method == 'POST':
        query = request.POST['query']
        api_url = "https://api.api-ninjas.com/v1/nutrition?query="   #taken from api ninjas
        api_request = requests.get(api_url+query,headers ={'X-Api-Key':'DCVMdrMM9Gaj2KEJUAF7ig==iuHAfu3JeQjphdAc'}) #api key 
        try:
           api = json.loads(api_request.content)
           print(api_request.content)
        except Exception as e:
           api = "oops! There was an error"
           print(e)
        return render(request,'home.html',{'api':api})
    else:
        
        return render(request,'home.html',{'query':'Enter a valid query'})
    

    # import requests 
    # query = '1lb brisket and fries'
    # api_url = 'https://api.api-ninjas.com/v1/nutrition?query={}'.format(query)
    # response = requests.get(api_url, headers={'X-Api-Key': 'DCVMdrMM9Gaj2KEJUAF7ig==iuHAfu3JeQjphdAc'})
    # if response.status_code == requests.codes.ok:
    #     print(response.text)
    # else:
    #     print("Error:", response.status_code, response.text)    
    